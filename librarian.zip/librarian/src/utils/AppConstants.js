// AppConstnats.js
export default Object.freeze({
    APP_NAME: "Librarian"
})