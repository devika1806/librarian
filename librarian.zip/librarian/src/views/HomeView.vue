<template>
  <div :style="`background-color:${randomColor()}`">
    <h1>Welcome to Librarian</h1>
  </div>
</template>

<script>

  export default {
    name: 'Home',

    components: {
    },
  }
</script>
